# Academic LaTeX Report Builder

## Project Status

This document is the initial source of truth for the project. It defines what we are building, who it is for, what belongs in the first version, and which capabilities are intentionally deferred.

The working name is **Academic LaTeX Report Builder**. The product is a browser-based, single-user report editor that combines the accessibility of a Notion-style block editor, the visual polish and templates of Canva, and the compilation workflow of Overleaf.

## Problem

LaTeX is an excellent system for producing consistent academic and technical documents. It handles equations, references, tables of contents, citations, figures, and long documents more reliably than many visual editors.

However, LaTeX remains difficult for many students, researchers, and educators because:

- Users must learn commands, environments, packages, and compilation rules before they can produce a useful document.
- Small syntax errors can stop compilation or produce errors that are difficult for beginners to understand.
- Reordering document content usually means moving source code rather than moving meaningful visual sections.
- Figures, tables, captions, citations, and cross-references require several related commands.
- Traditional code-first editors offer limited visual guidance while the report is being structured.
- General-purpose design tools provide visual freedom but do not protect academic consistency or generate maintainable LaTeX.

The project should make the common academic-report workflow approachable without losing the typography, structure, and portability that make LaTeX valuable.

## Vision

Users should be able to build a professional academic report by inserting, editing, duplicating, and reordering structured content blocks. The application will translate those blocks into valid LaTeX and continuously produce a live PDF preview.

A beginner should not need to understand LaTeX syntax to create a correctly structured report. An experienced user should still be able to inspect the generated source, export it, and use a controlled raw-LaTeX block when the visual tools are insufficient.

The product is a **structured document builder**, not a free-positioning canvas. Templates and layout rules should give users attractive results while protecting margins, typography, hierarchy, captions, numbering, and reference integrity.

## Initial Audience

The first version is designed primarily for LaTeX beginners:

- University students writing assignments, dissertations, and project reports
- Researchers preparing papers, technical reports, and working documents
- Educators creating course notes, handouts, and assessment material

Advanced LaTeX users are a secondary audience. They should benefit from faster document assembly and source export, but the MVP will not attempt to replace every feature of a full code-first LaTeX environment.

## Core User Experience

### Main workspace

The desktop workspace uses three coordinated areas:

1. **Left sidebar — project structure**
   - Document outline and section navigation
   - Academic templates
   - Uploaded files and figures
   - Bibliography and citation sources
   - Document settings and metadata

2. **Centre workspace — block editor**
   - Document content displayed in reading order
   - Drag handles for reordering blocks
   - A `/` command menu for inserting block types
   - Contextual controls for editing the selected block
   - Clear insertion indicators and drop targets
   - Keyboard navigation and multi-block selection

3. **Right sidebar — live output**
   - Continuously updated PDF preview
   - Compilation state and progress
   - Beginner-friendly errors and warnings
   - Navigation between a block and its rendered PDF location
   - Download actions for PDF and generated `.tex` files

The sidebars should be collapsible so users can focus on writing or previewing when needed.

### Advanced LaTeX mode

An optional advanced mode will allow users to:

- Inspect the generated LaTeX source
- Copy or export the source
- Add a controlled raw-LaTeX block
- View the original compiler message behind a simplified error

Generated LaTeX is not the primary editing surface. Direct edits to generated source will not be synchronized back into visual blocks in the MVP.

## Block Model

Every piece of report content is represented as a typed block. Blocks appear in a defined sequence and may contain structured properties, child blocks, or references to project assets.

The initial block catalogue includes:

| Block | Purpose |
| --- | --- |
| Title and metadata | Title, subtitle, authors, affiliations, date, and abstract metadata |
| Heading | Sections and subsections with stable identifiers |
| Paragraph | Main prose with inline emphasis, links, citations, math, and references |
| List | Ordered, unordered, and description lists |
| Quote | Block quotations with an optional source |
| Callout | Notes, definitions, warnings, and highlighted information |
| Equation | Inline or display mathematics with optional numbering and labels |
| Figure | Uploaded image, caption, label, width, and placement preference |
| Table | Structured rows and columns, caption, label, alignment, and header options |
| Citation | Citation selection and rendering from bibliography data |
| Bibliography | Generated reference list and citation-style settings |
| Cross-reference | References to headings, figures, tables, equations, and other labelled blocks |
| Code listing | Source code with language, caption, line-number, and formatting settings |
| Page or section break | Explicit structural boundaries where academically appropriate |
| Raw LaTeX | An advanced escape hatch with visible safety and portability warnings |

### Block interactions

Users must be able to:

- Insert a block using the `/` menu or an add button
- Drag a block to reorder it
- Move selected blocks with keyboard commands
- Duplicate, convert, or delete a block
- Undo and redo block or text changes
- Copy and paste one or more blocks
- See where a dragged block will be inserted before dropping it
- Navigate between a block, its outline entry, and its PDF output
- See validation feedback on the block that caused a problem

## Document and Compilation Model

Blocks are the canonical representation of a document. Generated LaTeX and PDF files are derived outputs.

```text
Block document
      ↓
Validation and reference resolution
      ↓
Template and style application
      ↓
Generated LaTeX source
      ↓
Sandboxed XeLaTeX compilation
      ↓
PDF preview and export
```

The canonical document should preserve stable block identifiers, block type, content, formatting properties, relationships, and asset references. This allows the editor to reorder content without manipulating LaTeX source directly.

XeLaTeX is the default compiler because it provides strong Unicode and modern-font support, including Traditional Chinese content. Compilation must run in an isolated environment with shell escape disabled and controlled access to project assets.

Each compilation result should include:

- Generated `.tex` source
- PDF output when compilation succeeds
- Structured errors and warnings
- A mapping between block identifiers and generated source locations
- A mapping between blocks and PDF locations when available

## MVP

The first usable version includes:

- Browser-based single-user editor
- Block insertion, editing, reordering, duplication, conversion, and deletion
- Slash-command block menu
- Local autosave and recovery
- Undo and redo
- Keyboard navigation and block movement
- Document outline generated from heading blocks
- Title, heading, paragraph, list, equation, figure, table, citation, bibliography, cross-reference, code, break, and raw-LaTeX blocks
- Academic starter templates
- Template-controlled page size, margins, typography, spacing, headers, and footers
- Validation before compilation
- Sandboxed XeLaTeX generation and compilation
- Live PDF preview
- Understandable compilation feedback with an advanced raw-log view
- PDF export
- Generated `.tex` export

### MVP quality requirements

- Autosave must not interrupt typing or block reordering.
- Reordering blocks must produce the same order in the exported LaTeX and PDF.
- Templates must prevent accidental overlap, clipping, and arbitrary off-page positioning.
- Citations and cross-references must remain connected when blocks are reordered.
- Compilation failures must preserve the user's document and identify the most relevant block.
- The interface must remain usable without requiring mouse-only drag operations.

## Design Principles

### Structured like Notion

Everything in the document is a selectable and movable block. Block handles, slash commands, keyboard operations, visible drop guides, and contextual menus should make report structure tangible without exposing LaTeX syntax.

Reference: [Notion writing and editing basics](https://www.notion.com/en-gb/help/writing-and-editing-basics)

### Approachable like Canva

Templates, restrained style controls, clear toolbars, strong visual hierarchy, and contextual editing should help users produce polished work quickly. Users should begin from reliable academic layouts rather than designing every page from an empty canvas.

Reference: [Canva editing and designing](https://www.canva.com/help/editing-designing/)

### Output-aware like Overleaf

The editor should connect project structure, document editing, compilation feedback, and live PDF output. Users should be able to move naturally between what they are editing and where it appears in the compiled report.

Reference: [Overleaf project used for workflow study](https://www.overleaf.com/project/6a603196b6e3bb06af0497cc)

### Academic structure over unlimited positioning

The application may borrow Canva's clarity and visual polish, but it should not adopt unrestricted object positioning. Academic templates, semantic blocks, and predictable layout rules are more important than pixel-level freedom.

### Progressive disclosure

Common actions should remain obvious and simple. Advanced options—placement hints, labels, raw compiler logs, package details, and raw LaTeX—should appear only when requested.

### Accessible interaction

Every essential drag-and-drop operation must also have a keyboard or menu equivalent. Focus indicators, labels, error messages, contrast, and reading order should be treated as core product requirements.

## Academic Template Strategy

Templates are controlled systems rather than decorative starting points. A template defines:

- Document class and supported packages
- Page size and margins
- Typefaces and language support
- Heading hierarchy
- Title-page and front-matter structure
- Header, footer, and page-number rules
- Caption and reference styles
- Bibliography style
- Permitted style choices for individual blocks

The first template set should cover:

- General academic report
- Research paper
- Dissertation or thesis draft
- Technical report
- Course notes or handout

Users can change template-level options, but individual blocks should not be able to undermine document-wide consistency.

## Explicit Non-Goals for the MVP

The first version will not include:

- Real-time multi-user collaboration or presence
- Comments, review assignments, or sharing permissions
- Arbitrary LaTeX import with reliable conversion back into blocks
- Synchronization of manual changes made to generated LaTeX
- A mobile-first editing experience
- A third-party plugin or package marketplace
- Unrestricted Canva-style object positioning
- Support for every LaTeX document class or package
- Automatic AI writing or citation generation as a dependency of the core editor

These boundaries protect the reliability of the block model and keep the first version focused on producing a complete report successfully.

## Roadmap

### Phase 1 — Editor foundation

- Block document model
- Core text and structural blocks
- Insertion, reordering, duplication, and deletion
- Local autosave and document recovery
- LaTeX generation
- Sandboxed XeLaTeX compilation
- Live PDF preview and basic compilation feedback

### Phase 2 — Academic workflow

- Academic template catalogue
- Bibliography and citation management
- Equations, figures, tables, code listings, and cross-references
- Project files and asset management
- Source-to-block and block-to-PDF navigation
- Improved validation and beginner-friendly error explanations

### Phase 3 — Cloud and collaboration

- User accounts and cloud projects
- Version history
- Project sharing and permissions
- Comments and review workflows
- Real-time collaborative editing

### Phase 4 — Assisted authoring

- AI-assisted report structuring
- Rewriting and clarity suggestions
- Citation discovery suggestions with source verification
- Accessibility and consistency checks
- Template and layout recommendations

AI features should assist user decisions rather than silently modify document content or invent academic sources.

## Success Criteria

The MVP is successful when a LaTeX beginner can complete the following workflow without editing LaTeX source:

1. Start a project from an academic template.
2. Add report metadata, headings, prose, a figure, a table, an equation, and citations.
3. Reorder sections and see the document outline update immediately.
4. Identify and fix a validation or compilation problem from feedback attached to the relevant block.
5. Preview the complete report as a PDF.
6. Export both a valid PDF and maintainable `.tex` source.

The product should additionally meet these measurable targets during usability testing:

- At least 80% of first-time users complete the core workflow without external LaTeX guidance.
- At least 90% of block reorder operations produce the expected document sequence.
- No user-authored content is lost after a compilation failure or page refresh following autosave.
- A user can identify the block responsible for a seeded validation error within one minute.
- All essential editing and reordering tasks can be completed using the keyboard.

## Product Decisions Recorded Here

- The first release is browser-based and single-user.
- Local autosave is required before cloud storage.
- Blocks are the canonical document model.
- Generated LaTeX is an export and inspection format, not the main editing state.
- XeLaTeX is the default compiler.
- Beginners are the primary audience.
- Academic consistency takes priority over unrestricted visual positioning.
- Advanced users receive source inspection, `.tex` export, raw logs, and a controlled raw-LaTeX block.

## Immediate Next Step

Translate this product brief into a technical design for the Phase 1 prototype, covering the block schema, editor framework, drag-and-drop and keyboard behavior, local persistence, LaTeX rendering boundary, compilation service, and PDF-preview integration.
