# FolioTeX

FolioTeX is a local-first academic report builder for people who want LaTeX-quality structure without writing every command by hand. Reports are assembled as movable blocks, previewed as a formatted paper, and exported as XeLaTeX source.

## What works

- Notion-style typed blocks with drag-and-drop, duplicate, delete, and keyboard-friendly move controls
- Headings, prose, lists, quotes, callouts, equations, figures, tables, citations, cross-references, code, page breaks, and controlled raw LaTeX
- Three-pane workspace with document outline, editor, browser preview, generated source, and validation checks
- Local autosave, undo/redo, sample reset, figure uploads, and responsive desktop layout
- `.tex` download and browser Print / Save PDF
- XeLaTeX output with Unicode and Traditional Chinese support through `xeCJK`

The browser preview is immediate and approximate. A future sandboxed compilation service will produce byte-identical XeLaTeX PDFs inside the app. For now, exported `.tex` can be compiled with a local TeX installation or an online LaTeX environment.

## Run locally

Requirements: Node.js 22.13 or newer and pnpm 11.

```bash
pnpm install
pnpm dev
```

Open the local URL printed by the development server (normally `http://localhost:5173`).

## Verify a production build

```bash
pnpm test
```

The product direction and MVP boundary are documented in [PROJECT_BRIEF.md](./PROJECT_BRIEF.md).
