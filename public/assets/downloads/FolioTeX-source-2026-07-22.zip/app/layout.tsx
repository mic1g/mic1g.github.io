import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FolioTeX — Academic Report Studio",
  description: "Build structured academic reports visually and export clean XeLaTeX source.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
