import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("http://localhost/", { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the FolioTeX studio", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>FolioTeX — Academic Report Studio<\/title>/i);
  assert.match(html, /FolioTeX/);
  assert.match(html, /academic report studio/i);
  assert.match(html, /Block library/);
  assert.match(html, /Export/);
  assert.doesNotMatch(html, /Codex is working|Your site is taking shape|react-loading-skeleton/i);
});

test("implements the local-first block and LaTeX workflow", async () => {
  const [page, layout, packageJson, brief] = await Promise.all([
    readFile(new URL("app/page.tsx", root), "utf8"),
    readFile(new URL("app/layout.tsx", root), "utf8"),
    readFile(new URL("package.json", root), "utf8"),
    readFile(new URL("PROJECT_BRIEF.md", root), "utf8"),
  ]);

  assert.match(page, /foliotex-document-v1/);
  assert.match(page, /function generateLatex/);
  assert.match(page, /draggable/);
  assert.match(page, /localStorage\.setItem/);
  assert.match(page, /window\.print\(\)/);
  assert.match(page, /Exported source is designed for XeLaTeX/);
  assert.match(page, /Raw LaTeX/);
  assert.match(page, /Citations? and bibliography|Citation/);
  assert.match(layout, /FolioTeX — Academic Report Studio/);
  assert.doesNotMatch(packageJson, /react-loading-skeleton/);
  assert.match(brief, /XeLaTeX/);
});
